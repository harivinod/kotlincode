package com.infosys.myrailways

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_history.*
import java.util.*


class history : AppCompatActivity() {
    lateinit var mydb: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        mydb = DatabaseHelper(this)
        mydb.writableDatabase
        val al = ArrayList<String>()
        val c = mydb.getalldata()
        if (c.count == 0) {
            Toast.makeText(this, "no data", Toast.LENGTH_SHORT).show()
        } else {

            // t1.setText(sb.toString());
            while (c.moveToNext()) {
                val sb = StringBuffer()
                sb.append("""
    Train No: ${c.getString(6)} """.trimIndent())
                sb.append("""Name: ${c.getString(0)} Email: ${c.getString(1)}""")
                sb.append("""Source: ${c.getString(2)} Destination: ${c.getString(3)}""")
                sb.append("""TDate: ${c.getString(4)} NUMOFPASS: ${c.getString(5)}""")
                al.add(sb.toString())

            }
           var adapter=HistoryAdapter(this,al)
            historylist.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
            historylist.adapter=adapter
            var itemDecoration = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
            getDrawable(R.drawable.divider)?.let { itemDecoration.setDrawable(it) }
            historylist.addItemDecoration(itemDecoration)
           // historylist.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        }
    }
}