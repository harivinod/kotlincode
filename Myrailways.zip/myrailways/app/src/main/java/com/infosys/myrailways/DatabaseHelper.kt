package com.infosys.myrailways

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        Log.d("db", "creating table")
        db.execSQL(" CREATE TABLE IF NOT EXISTS TRAINBOOKING (Name VARCHAR,Email VARCHAR,Source VARCHAR,Destination VARCHAR,TDate VARCHAR,NUMOFPASS VARCHAR,TrainNO VARCHAR);")
        Log.d("db", "created table")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onCreate(db)
    }

    fun insertdata(name: String, email: String, source: String, dest: String, tdate: String, pass: String, train: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("Name", name)
        contentValues.put("Email", email)
        contentValues.put("Source", source)
        contentValues.put("Destination", dest)
        contentValues.put("TDate", tdate)
        contentValues.put("NUMOFPASS", pass)
        contentValues.put("TrainNO", train)
        return db.insert("TRAINBOOKING", null, contentValues) != -1L
    }

    fun getalldata(): Cursor {
        val db = this.writableDatabase
        return db.rawQuery("select * from TRAINBOOKING ", null)
    }

    companion object {
        const val DATABASE_NAME = "TRAINDATA1.DB"
        const val TABLE_NAME = "BOOKINGDATA"
        const val name = "name"
        const val email = "email"
        const val source = "source"
        const val dest = "dest"
        const val tdate = "tdate"
        const val pass = "pass"
        const val train = "train"
    }
}