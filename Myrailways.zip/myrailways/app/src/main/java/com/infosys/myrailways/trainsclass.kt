package com.infosys.myrailways

data class trainsclass (var trainname:String,var trainnumber:String,var source:String,var dest:String)