package com.infosys.myrailways

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.trainitem.view.*


class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
{
    val trainname = itemView.trainname
    val trainnum = itemView.trainnum
    val source = itemView.source
    val dest = itemView.dest


    fun bind(train: trainsclass, clickListener: trainlist)
    {
        trainname.text = train.trainname
        trainnum.text = train.trainnumber
        source.text = train.source
        dest.text = train.dest


        itemView.setOnClickListener {
            clickListener.onItemClicked(train)
        }
    }

}
class RecyclerAdapter(var mylist:MutableList<trainsclass>, val itemClickListener: trainlist):RecyclerView.Adapter<MyHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, position: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.trainitem,parent,false)
        return MyHolder(view)


    }

    override fun getItemCount(): Int {
        return mylist.size
    }

    override fun onBindViewHolder(myHolder: MyHolder, position: Int) {
        val train = mylist.get(position)
        myHolder.bind(train,itemClickListener)


    }
}


interface OnItemClickListener{
    fun onItemClicked(train: trainsclass)
}