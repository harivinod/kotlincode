package com.infosys.myrailways

import android.app.Activity
import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.database.Cursor
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_booking.*
import java.util.*


class Booking : AppCompatActivity() {
    lateinit var preferences: SharedPreferences
    private lateinit var editor: Editor
    private lateinit var mydb: DatabaseHelper
    lateinit var picker: DatePickerDialog
    lateinit var result: Cursor
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                //newGame();
                finish()
                true
            }
            R.id.hist -> {
                val i = Intent(this@Booking, history::class.java)
                startActivity(i)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        //return super.onCreateOptionsMenu(menu);
        val inflater = menuInflater
        inflater.inflate(R.menu.mymenu, menu)
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SECOND_ACTIVITY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val returnString = data?.getStringExtra("train")
                txttrain.setText(returnString)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)
        mydb = DatabaseHelper(this)
        mydb.writableDatabase


        preferences = getSharedPreferences("mydata1", Context.MODE_PRIVATE)
        editor = preferences.edit()

        txtdate.setInputType(InputType.TYPE_NULL);
        txtdate.setOnClickListener(View.OnClickListener {
            val cldr: Calendar = Calendar.getInstance()
            val day: Int = cldr.get(Calendar.DAY_OF_MONTH)
            val month: Int = cldr.get(Calendar.MONTH)
            val year: Int = cldr.get(Calendar.YEAR)
            // date picker dialog
            picker = DatePickerDialog(this@Booking,
                    OnDateSetListener { view, year, monthOfYear, dayOfMonth -> txtdate.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })

        btnlist.setOnClickListener {
            val i = Intent(this@Booking, trainlist::class.java)
            startActivityForResult(i, SECOND_ACTIVITY_REQUEST_CODE)
        }
        btnbook.setOnClickListener {
            val name = preferences.getString("name", "NA")
            val email = preferences.getString("email", "NA")
            val source = txtsource.text.toString()
            val dest = txtdest.text.toString()
            val tdate = txtdate.text.toString()
            val pass = txtcount.text.toString()
            val train = txttrain.text.toString()
            var msg = ""
            msg = if (mydb.insertdata(name.toString(), email.toString(), source, dest, tdate, pass, train)) {
                "Booking Success!!"
            } else {
                "Booking Failed"
            }
            val builder = AlertDialog.Builder(this@Booking)
            builder.setTitle("Alert")
            builder.setMessage(msg)
            builder.setCancelable(false)
            builder.setPositiveButton("Yes") { dialog, which -> }.setNegativeButton("No") { dialog, which -> }.show()
        }
    }

    companion object {
        private const val SECOND_ACTIVITY_REQUEST_CODE = 0
    }
}