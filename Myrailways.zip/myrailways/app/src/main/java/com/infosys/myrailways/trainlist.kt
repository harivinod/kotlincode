package com.infosys.myrailways

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_trainlist.*

class trainlist : AppCompatActivity(),OnItemClickListener{
    private lateinit var adapter: RecyclerAdapter

    fun onItemClicked(train: trainsclass) {
        val selectedItem = train.trainnumber

        val intent = Intent()
        intent.putExtra("train", selectedItem)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trainlist)

        val trains = mutableListOf<trainsclass>()
        trains.add(trainsclass("abc","1234","Hyderabad","New York"))
        trains.add( trainsclass("xyz","4567","Banglore","New York"))
        trains.add(  trainsclass("ddd","3456","Mumbai","New York"))

        val tlist = findViewById<RecyclerView>(R.id.rvlist)
        tlist.layoutManager = LinearLayoutManager(this)
         adapter = RecyclerAdapter(trains,this)
        tlist.adapter = adapter


    }

    override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        TODO("Not yet implemented")
    }
}