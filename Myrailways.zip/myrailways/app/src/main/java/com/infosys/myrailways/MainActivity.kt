package com.infosys.myrailways

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
     lateinit var preferences: SharedPreferences
    lateinit var editor: Editor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preferences = getSharedPreferences("mydata1", Context.MODE_PRIVATE)
        editor = preferences.edit()
        val name = preferences.getString("name", "NA")
        val email = preferences.getString("email", "NA")
        val pwd = preferences.getString("pwd", "NA")
        if (name !== "NA") {
            // Toast.makeText(this,"no name",Toast.LENGTH_SHORT);
            // intent
            val i = Intent(this@MainActivity, Booking::class.java)
            startActivity(i)
        }
        btnlogin.setOnClickListener {
            editor.putString("name", txtname.getText().toString())
            editor.putString("email", txtemail.getText().toString())
            editor.putString("pwd", txtpwd.getText().toString())
            editor.apply()
            val i = Intent(this@MainActivity, Booking::class.java)
            startActivity(i)
        }
    }
}