package com.infosys.myrailways

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.historyitem.view.*

class HistoryAdapter(var ctx:Context,var myList:ArrayList<String>):RecyclerView.Adapter<HistoryAdapter.MyViewHolder>() {

    lateinit var myViewHolder: MyViewHolder
    class MyViewHolder(view: View): RecyclerView.ViewHolder(view)
    {
        var data:TextView=view.hitem

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
       var view=LayoutInflater.from(ctx).inflate(R.layout.historyitem,null,false)
        myViewHolder= MyViewHolder(view)
        return myViewHolder
    }

    override fun getItemCount(): Int {
        return myList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
       myViewHolder.data.text=myList[position]
    }
}